require("basic-lua-extensions")
require("config")

require("item-groups")
require("recipe-category")
require("items")
require("entity")

require("recipe")
require("recipe-raw")
require("recipe-others")


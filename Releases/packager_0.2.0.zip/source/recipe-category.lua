data:extend({
	{
		type = "recipe-category",
		name = "packager-pack"
	},
	{
		type = "recipe-category",
		name = "packager-advanced"
	}
})